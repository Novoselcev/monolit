var check = true;
$(document).ready(function () {


    $(".usl-block").hover(
        function () {
            animate($(this).children("span"));
        }
    );


    $(".animated").mouseenter(function () {
        animate($(this));
    });

   });
function animate(elem) {
    var effect = elem.data("effect");
    if (!effect || elem.hasClass(effect)) return false;
    elem.addClass(effect);
    setTimeout(function () {
        elem.removeClass(effect);
    }, 1000);
}
